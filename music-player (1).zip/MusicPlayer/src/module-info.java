/**
 * 
 */
/**
 * 
 */
module MusicPlayer {
}